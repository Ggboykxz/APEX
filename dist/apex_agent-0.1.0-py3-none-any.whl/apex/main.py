"""APEX CLI entry point - command parsing and interactive REPL."""

import argparse
import os
import sys
from pathlib import Path
from typing import Any

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.styles import Style

from .agent import Agent
from .config import Config, MODELS
from .ui import UI
from .memory import Memory
from .session import SessionManager
from .context import get_repo_map, get_language_stats
from rich.panel import Panel


memory = Memory()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="apex",
        description="APEX — The last coding agent you'll ever need",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("prompt", nargs="?", help="One-shot prompt to execute")
    parser.add_argument("--model", "-m", dest="model", help="Model alias to use")
    parser.add_argument("--cwd", "-C", dest="cwd", help="Working directory")
    parser.add_argument("--version", "-v", action="version", version="APEX 0.1.0")
    parser.add_argument("--list-models", action="store_true", help="List all available models")
    parser.add_argument("--one-shot", "-1", action="store_true", help="One-shot mode (non-interactive)")
    parser.add_argument("--stream", "-s", action="store_true", help="Enable streaming responses")
    parser.add_argument("--auto-commit", action="store_true", dest="auto_commit", help="Auto commit after successful task")
    return parser.parse_args()


def list_models(ui: UI) -> None:
    ui.show_models(Config().model)


def handle_command(command: str, agent: Agent, ui: UI, session: Any = None, use_stream: bool = False) -> bool:
    global memory
    parts = command.split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    match cmd:
        case "/model":
            if not arg:
                ui.print_error("Usage: /model <alias>")
                return True
            if agent.switch_model(arg):
                ui.print_success(f"Switched to model: {arg}")
            else:
                ui.print_error(f"Unknown model: {arg}")
            return True

        case "/models":
            ui.show_models(agent.model)
            return True

        case "/cwd":
            if not arg:
                ui.print_info(f"Current directory: {agent.cwd}")
                return True
            new_cwd = Path(arg).expanduser().resolve()
            if not new_cwd.exists():
                ui.print_error(f"Directory does not exist: {new_cwd}")
                return True
            if not new_cwd.is_dir():
                ui.print_error(f"Not a directory: {new_cwd}")
                return True
            agent.cwd = new_cwd
            os.chdir(new_cwd)
            ui.print_success(f"Changed directory to: {new_cwd}")
            return True

        case "/clear":
            agent.reset_history()
            ui.print_success("Conversation history cleared")
            return True

        case "/history":
            if not agent.history:
                ui.print_info("No conversation history")
                return True
            ui.console.print("[cyan]Conversation history:[/cyan]")
            for i, msg in enumerate(agent.history[-10:]):
                role = msg.get("role", "unknown")
                content = msg.get("content", "")
                if content:
                    truncated = content[:100] + "..." if len(content) > 100 else content
                    ui.console.print(f"  [{role}]: {truncated}")
            return True

        case "/cost":
            ui.print_cost(agent.usage)
            return True

        case "/save":
            sm = SessionManager()
            name = arg or "default"
            sm.save(agent, name)
            ui.print_success(f"Session saved as: {name}")
            return True

        case "/load":
            if not arg:
                ui.print_error("Usage: /load <name>")
                return True
            sm = SessionManager()
            loaded = sm.load(arg, agent)
            if loaded:
                ui.print_success(f"Session loaded: {arg}")
            else:
                ui.print_error(f"Session not found: {arg}")
            return True

        case "/sessions":
            sm = SessionManager()
            sessions = sm.list_sessions()
            if not sessions:
                ui.print_info("No saved sessions")
                return True
            ui.console.print("[cyan]Saved sessions:[/cyan]")
            for s in sessions:
                ui.console.print(f"  {s['name']} - {s['timestamp']} ({s['history_len']} messages)")
            return True

        case "/memory":
            if not arg:
                facts = memory.get_all()
                if not facts:
                    ui.print_info("No memory facts stored")
                else:
                    ui.console.print("[cyan]Memory facts:[/cyan]")
                    for i, f in enumerate(facts):
                        ui.console.print(f"  {i}: {f['fact']} [relevance: {', '.join(f.get('relevance', []))}]")
                return True

            mem_parts = arg.split(maxsplit=2)
            subcmd = mem_parts[0] if mem_parts else ""

            if subcmd == "add" and len(mem_parts) >= 3:
                fact = mem_parts[1]
                relevance = mem_parts[2].split(",") if len(mem_parts) > 2 else []
                memory.add(fact.strip(), [r.strip() for r in relevance])
                ui.print_success(f"Added to memory: {fact}")
            elif subcmd == "clear":
                memory.clear()
                ui.print_success("Memory cleared")
            elif subcmd == "search" and len(mem_parts) >= 2:
                results = memory.search(mem_parts[1])
                if not results:
                    ui.print_info("No matching facts found")
                else:
                    ui.console.print("[cyan]Search results:[/cyan]")
                    for f in results:
                        ui.console.print(f"  • {f['fact']}")
            else:
                ui.print_info("Usage: /memory [add <fact> <relevance>|clear|search <query>]")
            return True

        case "/map":
            repo_map = get_repo_map(agent.cwd)
            ui.console.print(Panel(repo_map, title="[cyan]Repository Map[/cyan]", border_style="cyan"))
            return True

        case "/stats":
            stats = get_language_stats(agent.cwd)
            if stats:
                ui.console.print("[cyan]Language stats:[/cyan]")
                for lang, count in sorted(stats.items(), key=lambda x: -x[1]):
                    ui.console.print(f"  {lang}: {count} files")
            else:
                ui.print_info("No source files found")
            return True

        case "/git":
            from .tools import ToolExecutor
            executor = ToolExecutor(cwd=agent.cwd)
            status = executor.execute("get_git_status", {})
            ui.console.print(Panel(status, title="[cyan]Git Status[/cyan]", border_style="cyan"))
            return True

        case "/help":
            ui.show_help()
            return True

        case "/exit" | "/quit":
            ui.print_info("Goodbye!")
            sys.exit(0)

        case _:
            if cmd.startswith("/"):
                ui.print_error(f"Unknown command: {cmd}. Type /help for available commands.")
                return True
            return False


async def run_repl_streaming(agent: Agent, ui: UI) -> None:
    history_file = Path.home() / ".apex" / "history"
    history_file.parent.mkdir(parents=True, exist_ok=True)

    bindings = KeyBindings()

    @bindings.add("c-c")
    def _(event):
        event.app.exit(exception=KeyboardInterrupt)

    style = Style.from_dict({
        "prompt": "cyan bold",
        "continuation": "cyan",
    })

    session = PromptSession(
        history=FileHistory(str(history_file)),
        key_bindings=bindings,
        style=style,
        prompt_message="› ",
    )

    ui.show_banner(agent.model, str(agent.cwd))
    ui.print_info("Type /help for available commands. Press Ctrl+C to exit.\n")

    while True:
        try:
            user_input = session.prompt()
            if not user_input.strip():
                continue
            if user_input.startswith("/"):
                if handle_command(user_input, agent, ui, session, use_stream=True):
                    continue
            ui.print_user(user_input)

            full_response = ""
            async for chunk in agent.chat_streaming(user_input):
                full_response += chunk
                ui.console.print(chunk, end="")
            ui.console.print()

        except KeyboardInterrupt:
            ui.print_info("\nType /exit to quit or /clear to clear history")
            continue
        except EOFError:
            break


def run_repl(agent: Agent, ui: UI, use_stream: bool = False) -> None:
    history_file = Path.home() / ".apex" / "history"
    history_file.parent.mkdir(parents=True, exist_ok=True)

    bindings = KeyBindings()

    @bindings.add("c-c")
    def _(event):
        event.app.exit(exception=KeyboardInterrupt)

    style = Style.from_dict({
        "prompt": "cyan bold",
        "continuation": "cyan",
    })

    session = PromptSession(
        history=FileHistory(str(history_file)),
        key_bindings=bindings,
        style=style,
        prompt_message="› ",
    )

    ui.show_banner(agent.model, str(agent.cwd))
    ui.print_info("Type /help for available commands. Press Ctrl+C to exit.\n")

    while True:
        try:
            user_input = session.prompt()
            if not user_input.strip():
                continue
            if user_input.startswith("/"):
                if handle_command(user_input, agent, ui, session, use_stream):
                    continue
            ui.print_user(user_input)
            with ui.console.status("[cyan]Thinking...[/cyan]", spinner="dots"):
                response = agent.chat(user_input)
            ui.print_response(response)
        except KeyboardInterrupt:
            ui.print_info("\nType /exit to quit or /clear to clear history")
            continue
        except EOFError:
            break


def run_one_shot(prompt: str, agent: Agent, ui: UI, use_stream: bool = False) -> None:
    if use_stream:
        full_response = ""
        ui.console.print("[cyan]Streaming response:[/cyan]")
        for chunk in agent.chat(prompt):
            full_response += chunk
            ui.console.print(chunk, end="")
        ui.console.print()
    else:
        with ui.console.status("[cyan]Thinking...[/cyan]", spinner="dots"):
            response = agent.chat(prompt)
        ui.print_response(response)


def main() -> None:
    args = parse_args()
    config = Config()
    if args.model:
        if args.model not in MODELS:
            print(f"Error: Unknown model '{args.model}'", file=sys.stderr)
            print(f"Use --list-models to see available models", file=sys.stderr)
            sys.exit(1)
        config.model = args.model
    if args.cwd:
        config.cwd = Path(args.cwd).expanduser().resolve()

    agent = Agent(config)
    ui = UI()

    if args.list_models:
        list_models(ui)
        sys.exit(0)

    if args.prompt:
        run_one_shot(args.prompt, agent, ui, args.stream)
    else:
        run_repl(agent, ui, args.stream)


if __name__ == "__main__":
    main()